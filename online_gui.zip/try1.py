
# coding: utf-8

# In[23]:



import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from matplotlib import pyplot
import csv
import sys
import os
import numpy as np
import pandas as pd
import csv


# In[24]:


#Step 1: Data Collection
df_train = pd.read_csv(r'C:\Users\Renganathan\Desktop\UNSW_NB15_training-set.csv')
df_train.head()


# In[25]:


df_test = pd.read_csv(r'C:\Users\Renganathan\Desktop\UNSW_NB15_testing-set.csv')
df_test.head()


# In[26]:


df = pd.concat([df_train, df_test])
df.head()
print (len(df))


# In[27]:


#Handle missing values by replacing the missing value with -99999
df.replace('-',-99999, inplace=True)
df.head(20)


# In[28]:


#Handle missing values by replacing the missing value with -99999
df.replace('no',-99999, inplace=True)
df.head(20)


# In[29]:


#Convert the nominal (categorial) attributes to numerical attributes
#converting 'protocol' feature to numerical value
lab_enc = LabelEncoder()
df['proto'] = lab_enc.fit_transform(df['proto'].astype('str'))
df.head()


# In[30]:


#converting 'service' feature to numerical value
df['service'].replace('ftp', 1 ,inplace=True)
df['service'].replace('smtp', 2 ,inplace=True)
df['service'].replace('snmp', 3 ,inplace=True)
df['service'].replace('http', 4 ,inplace=True)
df['service'].replace('ftp-data', 5 ,inplace=True)
df['service'].replace('dns', 6 ,inplace=True)
df['service'].replace('ssh', 7 ,inplace=True)
df['service'].replace('radius', 8 ,inplace=True)
df['service'].replace('pop3', 9 ,inplace=True)
df['service'].replace('dhcp', 10 ,inplace=True)
df['service'].replace('ssl', 11 ,inplace=True)
df['service'].replace('irc', 12 ,inplace=True)
df.head()


# In[31]:


#converting 'state' feature to numerical value
lab_enc = LabelEncoder()
df['state'] = lab_enc.fit_transform(df['state'].astype('str'))
df.head()


# In[32]:


#converting 'attack_cat' feature to numerical value
df['attack_cat'].replace('Normal', 0 ,inplace=True)
df['attack_cat'].replace('Fuzzers', 1 ,inplace=True)
df['attack_cat'].replace('Analysis', 2 ,inplace=True)
df['attack_cat'].replace('Backdoor', 3 ,inplace=True)
df['attack_cat'].replace('DoS', 4 ,inplace=True)
df['attack_cat'].replace('Exploits', 5 ,inplace=True)
df['attack_cat'].replace('Generic', 6 ,inplace=True)
df['attack_cat'].replace('Reconnaissance', 7 ,inplace=True)
df['attack_cat'].replace('Shellcode', 8 ,inplace=True)
df['attack_cat'].replace('Worms', 9 ,inplace=True)
df.head()


# In[33]:


#random shuffling of dataset 
df = df.sample(frac=1).reset_index(drop=True)
df.head()


# In[34]:


df["label"].replace({0: 1, 1: -1}, inplace=True)
df


# In[35]:


normal = ['0']
nor_obs = df[df.attack_cat.isin(normal)]
nor_obs.head()


# In[36]:


anomaly = ['1','2','3','4','5','6','7','8']
ano_obs = df[df.attack_cat.isin(anomaly)]
ano_obs.head()


# In[37]:


print(len(nor_obs))


# In[38]:


nor_features = nor_obs.iloc[0:80000, :]
columns = ['id','attack_cat','label']
nor_features = nor_features.drop(columns, axis = 1)
print(nor_features.head())


# In[39]:


def normalize(df):
    result = df.copy()
    for feature_name in df.columns:
        max_value = df[feature_name].max()
        min_value = df[feature_name].min()
        result[feature_name] = (df[feature_name] - min_value) / (max_value - min_value)
    return result


# In[40]:


x_train_1 = normalize(nor_features)
print(x_train_1.head())


# In[41]:


nor_features_2 = nor_obs.iloc[80000:93000, :]
columns = ['id','attack_cat','label']
nor_features_2 = nor_features_2.drop(columns, axis = 1)
print(nor_features_2.head())


# In[42]:


x_train_2 = normalize(nor_features_2)
print(x_train_2.head())


# In[44]:


y_train_1 = nor_obs.iloc[0:80000,-1]
print(y_train_1)


# In[45]:


print(len(y_train_1))


# In[46]:


y_train_2 = nor_obs.iloc[80000:93000,-1]
#print(y_train_2)


# In[47]:


#print(len(y_train_2))


# In[48]:


print(len(ano_obs))


# In[49]:


ano_features = ano_obs.iloc[0:164499, :]
columns = ['id','attack_cat','label']
ano_features = ano_obs.drop(columns, axis = 1)
print(ano_features)


# In[50]:


x_test = normalize(ano_features)
x_test["is_sm_ips_ports"].fillna("0.0", inplace = True) 
print(x_test)


# In[51]:


y_test = ano_obs.iloc[:,-1]
print(y_test)


# In[57]:


y_test_final = y_train_2.append(y_test)
print(y_test_final)


# In[52]:


x_train_1


# In[54]:


y_train_1


# In[55]:


x_test_final = x_train_2.append(x_test)
print(x_test_final)


# In[58]:


print(y_test_final)


# In[59]:


from sklearn import svm


# In[60]:


oneclass = svm.OneClassSVM(kernel='rbf', gamma=0.01, nu=0.95)
oneclass.fit(x_train_1)


# In[36]:





# In[61]:


fraud_pred = oneclass.predict(x_test_final)


# In[62]:


print(fraud_pred)


# In[63]:


print(y_test_final)


# In[64]:


from sklearn.metrics import accuracy_score
acc_score = accuracy_score(y_test_final, fraud_pred)
acc_percentage = acc_score * 100
print(acc_percentage)


# In[65]:


from sklearn.metrics import classification_report, confusion_matrix
print(confusion_matrix(y_test_final,fraud_pred))
print(classification_report(y_test_final,fraud_pred))



