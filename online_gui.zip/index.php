<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Intrusion Detection System using Machine Learning | Welcome</title>
    <link rel="stylesheet" type="text/css" href="CSS/style.css" media="all">


  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1>Intrusion Detection System</h1>
          </div>
          
      </div>
    </header>
    <form action="/" enctype="multipart/form-data" method="POST">
            <input type="file" name="file-to-upload">
            <input type="submit" value="Upload">
        </form>


  </body>
</html>
